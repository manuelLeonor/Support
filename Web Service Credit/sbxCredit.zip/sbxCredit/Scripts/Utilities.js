﻿
var startDate;
var endDate;
/*
SBX General Utilities
@author Elbert Castañeda<elbert.castaneda@gmail.com>
@requirements 
    jquery 1.10.*
*/

function getVarsUrl() {
    var url = window.parent.location.search.replace("?", "");
    var arrUrl = url.split("&");
    var urlObj = {};
    for (var i = 0; i < arrUrl.length; i++) {
        var x = arrUrl[i].split("=");
        urlObj[x[0]] = x[1]
    }
    return urlObj;
}

var isDebugging = getVarsUrl().debug;

String.prototype.endsWith = function (suffix) {
    return this.indexOf(suffix, this.length - suffix.length) !== -1;
};

var Utilities = {
    /*
    Utilities forDevExpress.Components
    */
    DX : {
        DataGridView: {
            /*
                Selected All Rows in a Data Grid View ofDevExpress.
                @param DX.DataGridView  grid
                @return boolean  Return true if all rows are checked
                @use 
                    Utilities.DX.DataGridView.ToggleSelectAll
            */
            ToggleSelectAll: function (grid) {

                var $grid       = $(grid);
                var checkedAll  = $grid.data("checkedAll");

                checkedAll      = typeof(checkedAll) != "undefined" ? checkedAll : false;

                if (!checkedAll) {
                    grid.SelectAllRowsOnPage();
                } else {
                    grid.UnselectAllRowsOnPage();
                }

                checkedAll = !checkedAll;
                $grid.data("checkedAll", checkedAll);

                return checkedAll;
            }

            /** 
                For the client event RowDblClick of the 
                GridView, enable edit row with this event
                @use 
                    Utilities.DX.DataGridView.OnRowDblClickEdit
            **/
            , OnRowDblClickEdit : function (s, e) {
                var srcElement = e.htmlEvent.srcElement;
                if (!s.IsEditing()) {
                    window.startDate = Date.now();
                    s.StartEditRow(e.visibleIndex);
                }
            }
            /** 
                For the client event Init of the GridView, enable map keys for grupo sync likes
                @use 
                    Utilities.DX.DataGridView.OnInitKeyPressMap
            **/
            , OnInitKeyPressMap : function (s, e) {
                ASPxClientUtils.AttachEventToElement(
                    s.GetMainElement(),
                    "keydown",
                    function (evt) {
                        switch (evt.keyCode) {
                            case 13:
                                if (!s.IsEditing()) {
                                    s.StartEditRow(s.GetFocusedRowIndex());
                                }
                                break;
                            case 27:
                                if (s.IsEditing()) {
                                    s.CancelEdit();
                                }
                                break;
                        }
                    }
                );
            }
        }
        , TreeList: {
            /** 
            For the client event RowDblClick of the 
            TreeList, enable edit row with this event
            @use 
                Utilities.DX.TreeList.OnRowDblClickEdit
            **/
            OnRowDblClickEdit : function (s, e) {
                var srcElement = e.htmlEvent.srcElement;
                s.StartEdit(s.GetFocusedNodeKey());
            }
            /** 
                For the client event Init of the TreeList, enable map keys for grupo sync likes
                @use 
                    Utilities.DX.TreeList.OnInitKeyPressMap
            **/
            , OnInitKeyPressMap : function (s, e) {
                ASPxClientUtils.AttachEventToElement(
                    s.GetMainElement(),
                    "keydown",
                    function (evt) {
                        switch (evt.keyCode) {
                            case 13:
                                if (!s.IsEditing()) {
                                    var key = s.GetFocusedNodeKey()
                                    s.StartEdit(key);
                                }
                                break;
                            case 27:
                                if (s.IsEditing()) {
                                    s.CancelEdit();
                                }
                                break;
                        }
                    }
                );
            }
        }
    }
}

window.onload = function () {
    if (typeof (grid) != "undefined") {
        var nameGrid = "";
        var partsNameGrid = grid.name.split(/_/g);
        nameGrid = partsNameGrid[partsNameGrid.length - 1];

        grid.realName = nameGrid;
        grid["isSaving"] = false;

        grid['__startEditGrid__'] = grid.StartEditRow;
        grid['__updateGrid__'] = grid.UpdateEdit;
        grid['__cancelGrid__'] = grid.CancelEdit;

        grid.StartEditRow = function (key) {
            this.__startEditGrid__(key);
        }

        grid.UpdateEdit = function() {
            this.isSaving = true;
            this.__updateGrid__();
            this.isSaving = false;
        }

        grid.GetForm = function() {
            return window[this.name + "_DXPEForm"];
        };

        grid.CancelEdit = function () {
            window[this.realName + "_cancelCloseWindow"] = false;
            var form = this.GetForm();

            var changesPen =
                typeof (window[this.realName + "_changeForm"]) != 'undefined' &&
                window[nameGrid + "_changeForm"];

            if (changesPen && ! this.isSaving){
                window[this.realName + "_cancelCloseWindow"] = !confirm('Hay cambios sin guardar ¿ Seguro que desea salir ?');
            }

            if (!window[this.realName + "_cancelCloseWindow"]) {
                delete window[this.realName + "_changeForm"];
                delete window[this.realName + "_cancelCloseWindow"];
                this.__cancelGrid__();
            }
            
        };

    }
};